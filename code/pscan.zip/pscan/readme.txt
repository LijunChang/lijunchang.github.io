One running example: 
./pscan dir epsilon mu [output]

./pscan ./test 0.2 3
./pscan ./test 0.2 3 output

output is stored as ${dir}/result-${epsilon}-${mu}.txt

Note that, this is compiled on Ubuntu 64bit.