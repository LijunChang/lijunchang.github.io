One running example: 
./topkSD dir k threshold [output]

./topkSD ./test 10 1
./topkSD ./test 10 1 output

Note that, this is compiled on Debian 64bit.